function cambiarcolor(nuevocolor){
    var about = document.getElementById("about");
    about.style.color = nuevocolor;
}

// var contact = document.getElementById("contact");



// var contenido1 = document.getElementById("contenido1");


function cambiartamano(nuevotamano){
    var imagen = document.getElementById("imagen");
    imagen.style.width=nuevotamano;
}
    