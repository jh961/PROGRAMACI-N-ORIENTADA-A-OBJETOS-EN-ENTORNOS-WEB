# ciclo3_diurno
