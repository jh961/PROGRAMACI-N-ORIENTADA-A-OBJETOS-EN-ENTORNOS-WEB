var nombre =document.getElementById("f_nombre");

