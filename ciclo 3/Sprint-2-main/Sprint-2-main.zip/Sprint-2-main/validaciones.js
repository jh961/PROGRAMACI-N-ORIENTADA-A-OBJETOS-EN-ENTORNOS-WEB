// este es el documento a editar

var usuario=document.getElementById("in_usuario");
    function validar_username(usuario){
        if(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[A-Za-z\d#$%&@]){3,9}[^\s]+$/.test(usuario)){
            return true;
        }else{
            return false;
        }
    }
var contrasena=document.getElementById("in_contrasena");
    function validar_contrasena(contrasena){
        // solucion grupo Contraseña
        if( /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[A-Za-z\d#$%&@]){6,}[^\s]+$/.test(contraseña)){
            return true;
        }else{
            return false;
        }
    } 
module.exports.validar_username = validar_username
module.exports.validar_contrasena = validar_contrasena
